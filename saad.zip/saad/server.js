const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || 'chave-de-desenvolvimento';
const BONUS = Number(process.env.BONUS_POR_PARTICIPACAO || 0.2);
const BONUS_MAX = Number(process.env.BONUS_MAXIMO || 1);

const db = new Database(process.env.DB_PATH || path.join(__dirname, 'saad.db'));
db.pragma('foreign_keys = ON');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const semestreDe = (d = new Date()) => `${d.getFullYear()}.${d.getMonth() < 6 ? 1 : 2}`;
const falha = (res, code, erro) => res.status(code).json({ erro });

const exigir = (...perfis) => (req, res, next) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  try {
    const dados = jwt.verify(token, SECRET);
    if (perfis.length && !perfis.includes(dados.perfil)) return falha(res, 403, 'Você não tem acesso a esta área.');
    req.usuario = dados;
    next();
  } catch {
    falha(res, 401, 'Faça login para continuar.');
  }
};

app.post('/api/auth/registro', (req, res) => {
  const { nome, email, senha, perfil, matricula, departamento } = req.body || {};
  if (!nome || !email || !senha || !['DOCENTE', 'DISCENTE'].includes(perfil)) return falha(res, 400, 'Preencha nome, e-mail, senha e perfil.');
  if (senha.length < 6) return falha(res, 400, 'A senha precisa ter ao menos 6 caracteres.');
  if (perfil === 'DISCENTE' && !matricula) return falha(res, 400, 'Informe sua matrícula.');
  try {
    const id = db.transaction(() => {
      const novo = db.prepare('INSERT INTO usuario (nome,email,senha_hash,perfil) VALUES (?,?,?,?)')
        .run(nome.trim(), email.trim().toLowerCase(), bcrypt.hashSync(senha, 10), perfil).lastInsertRowid;
      if (perfil === 'DOCENTE') db.prepare('INSERT INTO docente (usuario_id,departamento) VALUES (?,?)').run(novo, departamento || null);
      else db.prepare('INSERT INTO discente (usuario_id,matricula) VALUES (?,?)').run(novo, matricula.trim());
      return novo;
    })();
    const token = jwt.sign({ id, nome, perfil }, SECRET, { expiresIn: '8h' });
    res.status(201).json({ token, usuario: { id, nome, perfil } });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return falha(res, 409, 'E-mail ou matrícula já cadastrados.');
    falha(res, 500, 'Não foi possível concluir o cadastro.');
  }
});

app.post('/api/auth/login', (req, res) => {
  const { email, senha } = req.body || {};
  const u = db.prepare('SELECT * FROM usuario WHERE email = ?').get(String(email || '').trim().toLowerCase());
  if (!u || !bcrypt.compareSync(String(senha || ''), u.senha_hash)) return falha(res, 401, 'E-mail ou senha incorretos.');
  const token = jwt.sign({ id: u.id, nome: u.nome, perfil: u.perfil }, SECRET, { expiresIn: '8h' });
  res.json({ token, usuario: { id: u.id, nome: u.nome, perfil: u.perfil } });
});

app.get('/api/tipos', (req, res) => res.json(db.prepare('SELECT id, nome FROM tipo_atividade ORDER BY nome').all()));

app.get('/api/docentes', (req, res) => {
  res.json(db.prepare(`
    SELECT u.id, u.nome, d.departamento,
      (SELECT COUNT(*) FROM atividade a WHERE a.docente_id = u.id AND a.status = 'ATIVA') AS atividades_ativas
    FROM docente d JOIN usuario u ON u.id = d.usuario_id ORDER BY u.nome`).all());
});

const baseAtividades = `
  SELECT a.id, a.titulo, a.descricao, a.aceita_inscricao, a.vagas, a.status, a.semestre,
    a.docente_id, t.nome AS tipo, u.nome AS docente,
    (SELECT COUNT(*) FROM inscricao i WHERE i.atividade_id = a.id AND i.status IN ('APROVADO','CONCLUIDO')) AS ocupadas
  FROM atividade a
  JOIN tipo_atividade t ON t.id = a.tipo_id
  JOIN usuario u ON u.id = a.docente_id`;

app.get('/api/atividades', (req, res) => {
  const filtros = ["a.status = 'ATIVA'"];
  const args = [];
  if (req.query.docente) { filtros.push('a.docente_id = ?'); args.push(Number(req.query.docente)); }
  if (req.query.q) { filtros.push('(a.titulo LIKE ? OR u.nome LIKE ?)'); args.push(`%${req.query.q}%`, `%${req.query.q}%`); }
  if (req.query.inscricao === '1') filtros.push('a.aceita_inscricao = 1');
  res.json(db.prepare(`${baseAtividades} WHERE ${filtros.join(' AND ')} ORDER BY a.criado_em DESC`).all(...args));
});

app.get('/api/minhas-atividades', exigir('DOCENTE'), (req, res) => {
  res.json(db.prepare(`${baseAtividades} WHERE a.docente_id = ? ORDER BY a.criado_em DESC`).all(req.usuario.id));
});

const lerAtividade = (b) => {
  const titulo = String(b.titulo || '').trim();
  const vagas = b.vagas === '' || b.vagas == null ? null : Number(b.vagas);
  if (!titulo || !Number(b.tipo_id)) return { erro: 'Informe o título e o tipo da atividade.' };
  if (vagas !== null && (!Number.isInteger(vagas) || vagas < 1)) return { erro: 'O número de vagas deve ser um inteiro positivo.' };
  return { titulo, descricao: String(b.descricao || '').trim(), tipo_id: Number(b.tipo_id), aceita: b.aceita_inscricao ? 1 : 0, vagas: b.aceita_inscricao ? vagas : null };
};

app.post('/api/atividades', exigir('DOCENTE'), (req, res) => {
  const d = lerAtividade(req.body || {});
  if (d.erro) return falha(res, 400, d.erro);
  const semestre = semestreDe();
  const id = db.transaction(() => {
    const novo = db.prepare('INSERT INTO atividade (docente_id,tipo_id,titulo,descricao,aceita_inscricao,vagas,semestre) VALUES (?,?,?,?,?,?,?)')
      .run(req.usuario.id, d.tipo_id, d.titulo, d.descricao, d.aceita, d.vagas, semestre).lastInsertRowid;
    db.prepare("INSERT INTO historico_participacao (tipo_evento,usuario_id,atividade_id,titulo_atividade,semestre,pontos) VALUES ('ACAO_DOCENTE',?,?,?,?,0)")
      .run(req.usuario.id, novo, d.titulo, semestre);
    return novo;
  })();
  res.status(201).json({ id });
});

app.put('/api/atividades/:id', exigir('DOCENTE'), (req, res) => {
  const atual = db.prepare('SELECT * FROM atividade WHERE id = ? AND docente_id = ?').get(req.params.id, req.usuario.id);
  if (!atual) return falha(res, 404, 'Atividade não encontrada.');
  const b = req.body || {};
  if (Object.keys(b).length === 1 && b.status) {
    if (!['ATIVA', 'ENCERRADA'].includes(b.status)) return falha(res, 400, 'Status inválido.');
    db.prepare('UPDATE atividade SET status = ? WHERE id = ?').run(b.status, atual.id);
    return res.json({ ok: true });
  }
  const d = lerAtividade(b);
  if (d.erro) return falha(res, 400, d.erro);
  db.prepare('UPDATE atividade SET tipo_id=?, titulo=?, descricao=?, aceita_inscricao=?, vagas=? WHERE id=?')
    .run(d.tipo_id, d.titulo, d.descricao, d.aceita, d.vagas, atual.id);
  res.json({ ok: true });
});

app.delete('/api/atividades/:id', exigir('DOCENTE'), (req, res) => {
  const r = db.prepare('DELETE FROM atividade WHERE id = ? AND docente_id = ?').run(req.params.id, req.usuario.id);
  if (!r.changes) return falha(res, 404, 'Atividade não encontrada.');
  res.json({ ok: true });
});

app.post('/api/atividades/:id/inscricoes', exigir('DISCENTE'), (req, res) => {
  const a = db.prepare(`${baseAtividades} WHERE a.id = ?`).get(req.params.id);
  if (!a || a.status !== 'ATIVA') return falha(res, 404, 'Atividade não está disponível.');
  if (!a.aceita_inscricao) return falha(res, 400, 'Esta atividade não aceita inscrição de estudantes.');
  if (a.vagas !== null && a.ocupadas >= a.vagas) return falha(res, 409, 'Não há mais vagas disponíveis.');
  try {
    db.prepare('INSERT INTO inscricao (atividade_id,discente_id) VALUES (?,?)').run(a.id, req.usuario.id);
    res.status(201).json({ ok: true });
  } catch {
    falha(res, 409, 'Você já solicitou inscrição nesta atividade.');
  }
});

app.get('/api/minhas-inscricoes', exigir('DISCENTE'), (req, res) => {
  res.json(db.prepare(`
    SELECT i.id, i.status, i.criado_em, i.atividade_id, a.titulo, t.nome AS tipo, u.nome AS docente, a.semestre
    FROM inscricao i JOIN atividade a ON a.id = i.atividade_id
    JOIN tipo_atividade t ON t.id = a.tipo_id JOIN usuario u ON u.id = a.docente_id
    WHERE i.discente_id = ? ORDER BY i.criado_em DESC`).all(req.usuario.id));
});

app.get('/api/inscricoes/recebidas', exigir('DOCENTE'), (req, res) => {
  res.json(db.prepare(`
    SELECT i.id, i.status, i.criado_em, a.titulo, a.id AS atividade_id, u.nome AS discente, d.matricula
    FROM inscricao i JOIN atividade a ON a.id = i.atividade_id
    JOIN usuario u ON u.id = i.discente_id JOIN discente d ON d.usuario_id = i.discente_id
    WHERE a.docente_id = ?
    ORDER BY CASE i.status WHEN 'PENDENTE' THEN 0 WHEN 'APROVADO' THEN 1 ELSE 2 END, i.criado_em DESC`).all(req.usuario.id));
});

const transicoes = { PENDENTE: ['APROVADO', 'REJEITADO'], APROVADO: ['CONCLUIDO'] };

app.patch('/api/inscricoes/:id', exigir('DOCENTE'), (req, res) => {
  const novo = req.body && req.body.status;
  const i = db.prepare(`
    SELECT i.*, a.titulo, a.vagas, a.docente_id,
      (SELECT COUNT(*) FROM inscricao x WHERE x.atividade_id = a.id AND x.status IN ('APROVADO','CONCLUIDO')) AS ocupadas
    FROM inscricao i JOIN atividade a ON a.id = i.atividade_id WHERE i.id = ?`).get(req.params.id);
  if (!i || i.docente_id !== req.usuario.id) return falha(res, 404, 'Inscrição não encontrada.');
  if (!(transicoes[i.status] || []).includes(novo)) return falha(res, 400, 'Essa mudança de status não é permitida.');
  if (novo === 'APROVADO' && i.vagas !== null && i.ocupadas >= i.vagas) return falha(res, 409, 'As vagas desta atividade já foram preenchidas.');
  db.transaction(() => {
    db.prepare("UPDATE inscricao SET status = ?, decidido_em = datetime('now') WHERE id = ?").run(novo, i.id);
    if (novo === 'CONCLUIDO') {
      db.prepare("INSERT INTO historico_participacao (tipo_evento,usuario_id,atividade_id,titulo_atividade,semestre,pontos) VALUES ('PARTICIPACAO_DISCENTE',?,?,?,?,1)")
        .run(i.discente_id, i.atividade_id, i.titulo, semestreDe());
    }
  })();
  res.json({ ok: true });
});

app.get('/api/historico', exigir(), (req, res) => {
  res.json(db.prepare(`
    SELECT id, tipo_evento, titulo_atividade, semestre, pontos, registrado_em
    FROM historico_participacao WHERE usuario_id = ? ORDER BY id DESC`).all(req.usuario.id));
});

const ranking = (semestre, limite) => db.prepare(`
  SELECT u.id, u.nome, COUNT(*) AS participacoes, SUM(h.pontos) AS pontos
  FROM historico_participacao h JOIN usuario u ON u.id = h.usuario_id
  WHERE h.tipo_evento = 'PARTICIPACAO_DISCENTE' AND h.semestre = ?
  GROUP BY u.id ORDER BY pontos DESC, participacoes DESC, u.nome ASC ${limite ? 'LIMIT ' + limite : ''}`).all(semestre);

app.get('/api/destaques', (req, res) => {
  const semestre = req.query.semestre || semestreDe();
  const lista = ranking(semestre, 10).map((r, n) => ({ posicao: n + 1, nome: r.nome, participacoes: r.participacoes, pontos: r.pontos }));
  res.json({ semestre, destaques: lista });
});

app.get('/api/relatorio-bonificacao', exigir('DOCENTE'), (req, res) => {
  const semestre = req.query.semestre || semestreDe();
  const linhas = ranking(semestre).map((r, n) => ({
    posicao: n + 1,
    nome: r.nome,
    participacoes: r.participacoes,
    bonificacao: Math.min(Math.round(r.pontos * BONUS * 100) / 100, BONUS_MAX)
  }));
  res.json({ semestre, regra: { por_participacao: BONUS, maximo: BONUS_MAX }, alunos: linhas });
});

app.use('/api', (req, res) => falha(res, 404, 'Rota não encontrada.'));

app.use((err, req, res, next) => {
  console.error(err);
  falha(res, 500, 'Ocorreu um erro inesperado.');
});

app.listen(PORT, () => console.log(`SAAD rodando em http://localhost:${PORT}`));
