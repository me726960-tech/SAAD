CREATE TABLE IF NOT EXISTS usuario (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  senha_hash TEXT NOT NULL,
  perfil TEXT NOT NULL CHECK (perfil IN ('DOCENTE','DISCENTE')),
  criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS docente (
  usuario_id INTEGER PRIMARY KEY REFERENCES usuario(id) ON DELETE CASCADE,
  departamento TEXT
);

CREATE TABLE IF NOT EXISTS discente (
  usuario_id INTEGER PRIMARY KEY REFERENCES usuario(id) ON DELETE CASCADE,
  matricula TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS tipo_atividade (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS atividade (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  docente_id INTEGER NOT NULL REFERENCES docente(usuario_id) ON DELETE CASCADE,
  tipo_id INTEGER NOT NULL REFERENCES tipo_atividade(id),
  titulo TEXT NOT NULL,
  descricao TEXT,
  aceita_inscricao INTEGER NOT NULL DEFAULT 0 CHECK (aceita_inscricao IN (0,1)),
  vagas INTEGER CHECK (vagas IS NULL OR vagas > 0),
  status TEXT NOT NULL DEFAULT 'ATIVA' CHECK (status IN ('ATIVA','ENCERRADA')),
  semestre TEXT NOT NULL,
  criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inscricao (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  atividade_id INTEGER NOT NULL REFERENCES atividade(id) ON DELETE CASCADE,
  discente_id INTEGER NOT NULL REFERENCES discente(usuario_id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'PENDENTE' CHECK (status IN ('PENDENTE','APROVADO','REJEITADO','CONCLUIDO')),
  criado_em TEXT NOT NULL DEFAULT (datetime('now')),
  decidido_em TEXT,
  UNIQUE (atividade_id, discente_id)
);

CREATE TABLE IF NOT EXISTS historico_participacao (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo_evento TEXT NOT NULL CHECK (tipo_evento IN ('ACAO_DOCENTE','PARTICIPACAO_DISCENTE')),
  usuario_id INTEGER NOT NULL REFERENCES usuario(id),
  atividade_id INTEGER,
  titulo_atividade TEXT NOT NULL,
  semestre TEXT NOT NULL,
  pontos INTEGER NOT NULL DEFAULT 0,
  registrado_em TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_atividade_docente ON atividade(docente_id, status);
CREATE INDEX IF NOT EXISTS idx_inscricao_discente ON inscricao(discente_id);
CREATE INDEX IF NOT EXISTS idx_hist_ranking ON historico_participacao(tipo_evento, semestre, usuario_id);

CREATE TRIGGER IF NOT EXISTS historico_sem_update
BEFORE UPDATE ON historico_participacao
BEGIN SELECT RAISE(ABORT, 'Historico e imutavel'); END;

CREATE TRIGGER IF NOT EXISTS historico_sem_delete
BEFORE DELETE ON historico_participacao
BEGIN SELECT RAISE(ABORT, 'Historico e imutavel'); END;

INSERT OR IGNORE INTO tipo_atividade (nome) VALUES
  ('Projeto de Iniciação Científica'),
  ('Curso de Extensão'),
  ('Banca de Seleção'),
  ('Comissão Interna');
