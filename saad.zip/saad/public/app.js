const app = document.getElementById('app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let sessao = null;
try { sessao = JSON.parse(localStorage.getItem('saad')); } catch { sessao = null; }
let aba = null;
let aviso = null;

async function api(url, o = {}) {
  const r = await fetch('/api' + url, {
    method: o.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(sessao ? { Authorization: 'Bearer ' + sessao.token } : {}) },
    body: o.body ? JSON.stringify(o.body) : undefined
  });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && sessao) { sair(false); }
  if (!r.ok) throw new Error(d.erro || 'Algo deu errado. Tente novamente.');
  return d;
}

function guardar(s) {
  sessao = s;
  try { s ? localStorage.setItem('saad', JSON.stringify(s)) : localStorage.removeItem('saad'); } catch {}
}
function sair(ir = true) { guardar(null); aba = null; if (ir) location.hash = '#/destaques'; else render(); }
function dizer(texto, tipo = 'ok') { aviso = { texto, tipo }; }
function caixaAviso() {
  if (!aviso) return '';
  const h = `<div class="msg ${aviso.tipo}">${esc(aviso.texto)}</div>`;
  aviso = null;
  return h;
}
const dataBR = s => new Date(s.replace(' ', 'T') + 'Z').toLocaleDateString('pt-BR');
const tagStatus = s => `<span class="tag ${{PENDENTE:'warn',APROVADO:'ok',CONCLUIDO:'ok',REJEITADO:'bad'}[s] || ''}">${{PENDENTE:'Aguardando',APROVADO:'Aprovado',CONCLUIDO:'Concluído',REJEITADO:'Rejeitado'}[s] || s}</span>`;

function montarNav(rota) {
  const itens = [['#/destaques', 'Destaques'], ['#/atividades', 'Atividades']];
  if (sessao) itens.push(['#/painel', 'Meu painel']); else itens.push(['#/entrar', 'Entrar']);
  document.getElementById('nav').innerHTML = itens.map(([h, t]) => `<a href="${h}" class="${rota === h ? 'on' : ''}">${t}</a>`).join('')
    + (sessao ? `<a href="#" onclick="sair();return false">Sair (${esc(sessao.usuario.nome.split(' ')[0])})</a>` : '');
}

async function vDestaques() {
  const d = await api('/destaques');
  app.innerHTML = `<h1>Destaques do semestre ${esc(d.semestre)}</h1>
    <p class="sub">Estudantes que mais participaram de ações com docentes neste semestre.</p>${caixaAviso()}
    ${d.destaques.length ? d.destaques.map(x => `<div class="card pod"><span class="pos">${x.posicao}º</span><div><strong>${esc(x.nome)}</strong><div class="mut">${x.participacoes} participação(ões) concluída(s)</div></div></div>`).join('')
      : '<div class="card empty">Ainda não há participações concluídas neste semestre.</div>'}`;
}

function cartaoAtividade(a, minhas = {}) {
  const livre = a.vagas === null ? 'Vagas ilimitadas' : `${a.vagas - a.ocupadas} de ${a.vagas} vagas`;
  let acao = '';
  if (!a.aceita_inscricao) acao = '<span class="mut">Não recebe inscrições</span>';
  else if (sessao && sessao.usuario.perfil === 'DISCENTE') {
    const st = minhas[a.id];
    acao = st ? tagStatus(st) : (a.vagas !== null && a.ocupadas >= a.vagas ? '<span class="tag bad">Sem vagas</span>' : `<button class="b" onclick="inscrever(${a.id})">Quero me inscrever</button>`);
  } else if (!sessao) acao = '<a href="#/entrar" class="mut">Entre para se inscrever</a>';
  return `<div class="card"><span class="tag">${esc(a.tipo)}</span>
    <h3 style="margin:8px 0 4px">${esc(a.titulo)}</h3>
    <div class="mut">Prof. ${esc(a.docente)} · ${esc(a.semestre)}</div>
    <p>${esc(a.descricao) || '<span class="mut">Sem descrição.</span>'}</p>
    <div class="row"><span class="mut">${a.aceita_inscricao ? livre : ''}</span>${acao}</div></div>`;
}

async function vAtividades() {
  const [docentes, minhas] = await Promise.all([
    api('/docentes'),
    sessao && sessao.usuario.perfil === 'DISCENTE' ? api('/minhas-inscricoes') : []
  ]);
  const mapa = Object.fromEntries(minhas.map(i => [i.atividade_id, i.status]));
  app.innerHTML = `<h1>Atividades ativas</h1><p class="sub">Encontre ações dos professores e veja onde há vagas.</p>${caixaAviso()}
    <div class="card"><div class="row" style="gap:12px">
      <div style="flex:2;min-width:200px"><label>Buscar por título ou professor</label><input id="q" placeholder="Ex.: iniciação científica"></div>
      <div style="flex:1;min-width:180px"><label>Professor</label><select id="fd"><option value="">Todos</option>${docentes.map(d => `<option value="${d.id}">${esc(d.nome)} (${d.atividades_ativas})</option>`).join('')}</select></div>
      <div class="chk" style="margin-top:26px"><input type="checkbox" id="fi"><span>Só com inscrição</span></div>
    </div></div><div id="lista" class="grid"></div>`;
  const carregar = async () => {
    const p = new URLSearchParams();
    const q = document.getElementById('q').value.trim();
    if (q) p.set('q', q);
    if (document.getElementById('fd').value) p.set('docente', document.getElementById('fd').value);
    if (document.getElementById('fi').checked) p.set('inscricao', '1');
    const lista = await api('/atividades?' + p);
    document.getElementById('lista').innerHTML = lista.length ? lista.map(a => cartaoAtividade(a, mapa)).join('') : '<div class="empty" style="grid-column:1/-1">Nenhuma atividade encontrada.</div>';
  };
  let t;
  document.getElementById('q').oninput = () => { clearTimeout(t); t = setTimeout(carregar, 300); };
  document.getElementById('fd').onchange = carregar;
  document.getElementById('fi').onchange = carregar;
  await carregar();
}

async function inscrever(id) {
  try { await api(`/atividades/${id}/inscricoes`, { method: 'POST' }); dizer('Pedido enviado! O professor vai analisar sua inscrição.'); }
  catch (e) { dizer(e.message, 'bad'); }
  render();
}

function vEntrar() {
  app.innerHTML = `<div class="auth"><h1>Bem-vindo(a)</h1><p class="sub">Entre ou crie sua conta para participar.</p>${caixaAviso()}
    <div class="card" id="boxLogin"><h2 style="margin-top:0">Entrar</h2>
      <label>E-mail</label><input id="le" type="email" autocomplete="username">
      <label>Senha</label><input id="ls" type="password" autocomplete="current-password">
      <p><button class="b" id="bl">Entrar</button></p></div>
    <div class="card"><h2 style="margin-top:0">Criar conta</h2>
      <label>Sou</label><select id="rp"><option value="DISCENTE">Estudante</option><option value="DOCENTE">Professor(a)</option></select>
      <label>Nome completo</label><input id="rn">
      <label>E-mail</label><input id="re" type="email">
      <label>Senha (mínimo 6 caracteres)</label><input id="rs" type="password" autocomplete="new-password">
      <div id="extra"></div>
      <p><button class="b o" id="br">Criar conta</button></p></div></div>`;
  const extra = () => {
    document.getElementById('extra').innerHTML = document.getElementById('rp').value === 'DISCENTE'
      ? '<label>Matrícula</label><input id="rm">' : '<label>Departamento ou área</label><input id="rd">';
  };
  extra();
  document.getElementById('rp').onchange = extra;
  const entrar = async (url, body) => {
    try { const d = await api(url, { method: 'POST', body }); guardar(d); aba = null; location.hash = '#/painel'; render(); }
    catch (e) { dizer(e.message, 'bad'); vEntrar(); }
  };
  document.getElementById('bl').onclick = () => entrar('/auth/login', { email: le.value, senha: ls.value });
  document.getElementById('br').onclick = () => entrar('/auth/registro', {
    perfil: rp.value, nome: rn.value, email: re.value, senha: rs.value,
    matricula: document.getElementById('rm')?.value, departamento: document.getElementById('rd')?.value
  });
}

function abas(lista) {
  return `<div class="tabs">${lista.map(([k, t]) => `<button class="${aba === k ? 'on' : ''}" onclick="aba='${k}';render()">${t}</button>`).join('')}</div>`;
}

function linhasHistorico(h) {
  return h.length ? `<div class="scroll"><table><tr><th>Data</th><th>Registro</th><th>Atividade</th><th>Semestre</th></tr>${h.map(x =>
    `<tr><td>${dataBR(x.registrado_em)}</td><td>${x.tipo_evento === 'ACAO_DOCENTE' ? 'Ação cadastrada' : 'Participação concluída'}</td><td>${esc(x.titulo_atividade)}</td><td>${esc(x.semestre)}</td></tr>`).join('')}</table></div>`
    : '<div class="empty">Seu histórico ainda está vazio.</div>';
}

async function painelDiscente() {
  aba = aba || 'inscricoes';
  const ins = await api('/minhas-inscricoes');
  let corpo = '';
  if (aba === 'inscricoes') {
    corpo = ins.length ? ins.map(i => `<div class="card row"><div><strong>${esc(i.titulo)}</strong><div class="mut">${esc(i.tipo)} · Prof. ${esc(i.docente)} · pedido em ${dataBR(i.criado_em)}</div></div>${tagStatus(i.status)}</div>`).join('')
      : '<div class="card empty">Você ainda não se inscreveu em nada. <a href="#/atividades">Ver atividades</a></div>';
  } else corpo = `<div class="card">${linhasHistorico(await api('/historico'))}</div>`;
  app.innerHTML = `<h1>Olá, ${esc(sessao.usuario.nome.split(' ')[0])}!</h1><p class="sub">Acompanhe suas inscrições e participações.</p>${caixaAviso()}
    <div class="card row"><span>Quer participar de algo novo?</span><a href="#/atividades"><button class="b">Buscar professores e vagas</button></a></div>
    ${abas([['inscricoes', 'Minhas inscrições'], ['historico', 'Meu histórico']])}${corpo}`;
}

async function painelDocente() {
  aba = aba || 'atividades';
  let corpo = '';
  if (aba === 'atividades') {
    const [tipos, minhas] = await Promise.all([api('/tipos'), api('/minhas-atividades')]);
    corpo = `<div class="card"><h2 style="margin-top:0">Nova atividade</h2>
      <label>Tipo</label><select id="nt">${tipos.map(t => `<option value="${t.id}">${esc(t.nome)}</option>`).join('')}</select>
      <label>Título</label><input id="ntit">
      <label>Descrição</label><textarea id="nd" rows="3"></textarea>
      <div class="chk"><input type="checkbox" id="na"><span>Permitir inscrição de estudantes</span></div>
      <div id="nvw" style="display:none"><label>Número de vagas (deixe vazio para ilimitado)</label><input id="nv" type="number" min="1"></div>
      <p><button class="b" onclick="criar()">Cadastrar atividade</button></p></div>
      <h2>Minhas atividades</h2>` + (minhas.length ? minhas.map(a => `<div class="card"><div class="row"><div><span class="tag">${esc(a.tipo)}</span> <span class="tag ${a.status === 'ATIVA' ? 'ok' : ''}">${a.status === 'ATIVA' ? 'Ativa' : 'Encerrada'}</span>
        <h3 style="margin:8px 0 2px">${esc(a.titulo)}</h3><div class="mut">${a.aceita_inscricao ? `${a.ocupadas} aluno(s) aprovado(s)${a.vagas ? ' de ' + a.vagas + ' vagas' : ''}` : 'Sem inscrição de estudantes'} · ${esc(a.semestre)}</div></div>
        <div><button class="b o" onclick="mudar(${a.id},'${a.status === 'ATIVA' ? 'ENCERRADA' : 'ATIVA'}')">${a.status === 'ATIVA' ? 'Encerrar' : 'Reativar'}</button>
        <button class="b r" onclick="excluir(${a.id})">Excluir</button></div></div></div>`).join('') : '<div class="card empty">Você ainda não cadastrou atividades.</div>');
  } else if (aba === 'aprovacoes') {
    const l = await api('/inscricoes/recebidas');
    corpo = l.length ? l.map(i => `<div class="card row"><div><strong>${esc(i.discente)}</strong> <span class="mut">· matrícula ${esc(i.matricula)}</span><div class="mut">${esc(i.titulo)} · pedido em ${dataBR(i.criado_em)}</div></div>
      <div>${i.status === 'PENDENTE' ? `<button class="b" onclick="decidir(${i.id},'APROVADO')">Aprovar</button> <button class="b r" onclick="decidir(${i.id},'REJEITADO')">Rejeitar</button>`
        : i.status === 'APROVADO' ? `${tagStatus(i.status)} <button class="b o" onclick="decidir(${i.id},'CONCLUIDO')">Marcar como concluída</button>` : tagStatus(i.status)}</div></div>`).join('')
      : '<div class="card empty">Nenhum pedido de inscrição por enquanto.</div>';
  } else if (aba === 'historico') {
    corpo = `<div class="card">${linhasHistorico(await api('/historico'))}</div>`;
  } else {
    const r = await api('/relatorio-bonificacao');
    corpo = `<p class="mut">Semestre ${esc(r.semestre)} · ${r.regra.por_participacao} ponto(s) por participação, limitado a ${r.regra.maximo} ponto(s).</p>` +
      (r.alunos.length ? `<div class="card scroll"><table><tr><th>#</th><th>Estudante</th><th>Participações</th><th>Bonificação sugerida</th></tr>${r.alunos.map(a =>
        `<tr><td>${a.posicao}</td><td>${esc(a.nome)}</td><td>${a.participacoes}</td><td>+${a.bonificacao.toFixed(2).replace('.', ',')}</td></tr>`).join('')}</table></div>`
        : '<div class="card empty">Ninguém concluiu participações neste semestre ainda.</div>');
  }
  app.innerHTML = `<h1>Painel do professor</h1><p class="sub">Cadastre ações, aprove estudantes e acompanhe o engajamento.</p>${caixaAviso()}
    ${abas([['atividades', 'Atividades'], ['aprovacoes', 'Aprovações'], ['historico', 'Histórico'], ['relatorio', 'Relatório de bonificação']])}${corpo}`;
  const chk = document.getElementById('na');
  if (chk) chk.onchange = () => { document.getElementById('nvw').style.display = chk.checked ? 'block' : 'none'; };
}

async function acao(fn, ok) {
  try { await fn(); if (ok) dizer(ok); } catch (e) { dizer(e.message, 'bad'); }
  render();
}
const criar = () => acao(() => api('/atividades', { method: 'POST', body: {
  tipo_id: nt.value, titulo: ntit.value, descricao: nd.value, aceita_inscricao: na.checked, vagas: nv.value
} }), 'Atividade cadastrada com sucesso.');
const mudar = (id, status) => acao(() => api('/atividades/' + id, { method: 'PUT', body: { status } }), 'Atividade atualizada.');
const excluir = id => confirm('Excluir esta atividade e suas inscrições?') && acao(() => api('/atividades/' + id, { method: 'DELETE' }), 'Atividade excluída.');
const decidir = (id, status) => acao(() => api('/inscricoes/' + id, { method: 'PATCH', body: { status } }), 'Inscrição atualizada.');

async function render() {
  const rota = location.hash || '#/destaques';
  montarNav(rota);
  try {
    if (rota === '#/atividades') await vAtividades();
    else if (rota === '#/entrar') vEntrar();
    else if (rota === '#/painel') {
      if (!sessao) { location.hash = '#/entrar'; return; }
      sessao.usuario.perfil === 'DOCENTE' ? await painelDocente() : await painelDiscente();
    } else await vDestaques();
  } catch (e) {
    app.innerHTML = `<div class="msg bad">${esc(e.message)}</div>`;
  }
}
window.addEventListener('hashchange', () => { aba = null; render(); });
render();
